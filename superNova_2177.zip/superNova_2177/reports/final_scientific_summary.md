# Final Scientific Summary
Generated: 2025-07-24T05:51:43.153596

## time_weighted_weight
{"source": "Exponential Decay", "model_type": "TimeWeightedEdge", "approximation": "simulated"}
## calculate_influence_score
{"source": "Brin & Page 1998", "model_type": "PageRank", "approximation": "simulated"}
## calculate_interaction_entropy
{"source": "Shannon 1948", "model_type": "Entropy", "approximation": "simulated"}
## query_influence
{"source": "Graph Theory", "model_type": "InfluencePropagation", "approximation": "simulated"}
## measure_superposition
{"source": "Quantum Mechanics", "model_type": "Measurement", "approximation": "stochastic"}